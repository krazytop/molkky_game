CREATE DATABASE molkky DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE equipes (
idEquipe INT NOT NULL AUTO_INCREMENT,
nom VARCHAR(255) NOT NULL,
PRIMARY KEY (idEquipe)
);

CREATE TABLE matchs (
idMatch INT NOT NULL AUTO_INCREMENT,
idEquipe1 INT NOT NULL,
idEquipe2 INT NOT NULL,
scoreEquipe1 INT,
scoreEquipe2 INT,
PRIMARY KEY (idMatch),
FOREIGN KEY (idEquipe1) REFERENCES equipes(idEquipe),
FOREIGN KEY (idEquipe2) REFERENCES equipes(idEquipe)
);

CREATE TABLE lances (
idLance INT NOT NULL AUTO_INCREMENT,
idMatch INT NOT NULL,
idEquipe INT NOT NULL,
valeurLancer INT,
PRIMARY KEY (idLance),
FOREIGN KEY (idMatch) REFERENCES matchs(idMatch),
FOREIGN KEY (idEquipe) REFERENCES equipes(idEquipe)
);